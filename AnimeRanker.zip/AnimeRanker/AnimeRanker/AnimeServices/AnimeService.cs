﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AnimeRanker.Models;

namespace AnimeRanker.AnimeServices
{
    public class AnimeService : IAnimeService
    {
        public List<Anime> ranker { get; set; }

        public void MyMethod() { }

        public AnimeService()
        {
            ranker = new List<Anime>();
            
        }
    }
}