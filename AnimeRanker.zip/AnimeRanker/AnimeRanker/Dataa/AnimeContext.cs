﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using AnimeRanker.Models;

namespace AnimeRanker.Dataa
{
    public class AnimeContext : DbContext
    {
        public AnimeContext(DbContextOptions<AnimeContext> options) : base(options)
        {

        }

        public DbSet<Anime> AnimeTable { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Anime>().HasData(

            (new Anime() { Id = 1, Name = "Attack on Titan", ReleaseYear = "4/7/13", EpisodeCount = 256, Description = "The plot of Attack on Titan centers on a civilization inside three walls, the last location where humans still live. Over one hundred years ago, humanity was driven to the brink of extinction after the emergence of humanoid giants called Titans, who attack and eat humans on sight." }),
            (new Anime() { Id = 2, Name = "Naruto", ReleaseYear = "9/21/99", EpisodeCount = 712, Description = "Naruto is an orphan who has a dangerous fox-like entity known as Kurama the Nine-Tailed Fox sealed within his body by his father, the Fourth Hokage Minato Namikaze, the leader of Konoha's ninja force, at the cost of his own life and that of his wife, Kushina Uzumaki." }),
            (new Anime() { Id = 3, Name = "One Peice", ReleaseYear = "10/20/99", EpisodeCount = 999, Description = "One Piece (stylized as ONE PIECE) is a Japanese anime television series based on Eiichiro Oda's manga series of the same name. The story follows the adventures of Monkey D. Luffy, a boy whose body gained the properties of rubber after unintentionally eating a Devil Fruit." }),
            (new Anime() { Id = 4, Name = "World Trigger", ReleaseYear = "10/5/14", EpisodeCount = 157, Description = "The story follows a Yuma Kuga who transfers to Third Mikado City Middle School where he meets another boy named who is a Border Agent. However, it turns out that Yuma is actually a Humanoid Neighbor, and his arrival signifies that not all is what it seems in the war against the Neighbors." }),
            (new Anime() { Id = 5, Name = "Made in Abyss", ReleaseYear = "7/7/17", EpisodeCount = 36, Description = "Made in Abyss is the Anime adaptation of the Manga of the same name by Akihito Tsukushi. It was directed by Masayuki Kojima at Kinema Citrus, with Hideyuki Kurata writing scripts as well as Kazuchika Kise designing the characters. The anime premiered on July 7, 2017 on AT-X and other channels." })
                );
        }
    }
}
