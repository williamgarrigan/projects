﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace AnimeRanker.Models
{
    public class Anime
    {
        [Required]
        public int Id { get; set; }

        [Display(Name = "Title: ")]
        public string Name { get; set; }


        
        [Display(Name = "Released: ")]
        public string ReleaseYear { get; set; }


        [Display(Name = "Episode Count: ")]
        public int EpisodeCount {get; set;}
        [Display(Name = "Description: ")]
        public string Description { get; set; }

        [Display(Name = "Reviews: ")]
        public string Reviews { get; set; }
    }
}
