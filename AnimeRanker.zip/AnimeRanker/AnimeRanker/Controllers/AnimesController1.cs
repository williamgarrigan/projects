﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AnimeRanker.Models;
using AnimeRanker.AnimeServices;
using AnimeRanker.Dataa;

namespace AnimeRanker.Controllers
{
    public class AnimesController : Controller
    {

        private AnimeContext dbContext;

        public AnimesController(AnimeContext db)
        {
            dbContext = db;
        }
        public IActionResult Index()
        {
            return View("ShowAll", dbContext.AnimeTable.ToList());
        }
        public IActionResult DisplayAll()
        {
            return RedirectToAction("Index");
        }
        public IActionResult AnimeDetails(int id)
        {
            Anime sh = dbContext.AnimeTable.SingleOrDefault(m => m.Id == id);
            if (sh != null)
                return View(sh);

            //we only get here is the shoe.id was not found
            return NotFound();//404 error - page not found
        }
        public IActionResult ShowAll(int id)
        {
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }






        [HttpPost]
        public IActionResult Add(Anime newAnime)
        {
            if (!ModelState.IsValid)  //if data is invalid
            {
                return View();
            }
            dbContext.AnimeTable.Add(newAnime);
            dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Delete(int id)
        {
            Anime sh = dbContext.AnimeTable.SingleOrDefault(m => m.Id == id);
            if (sh != null)
            {
                dbContext.AnimeTable.Remove(sh);
                dbContext.SaveChanges();
                return RedirectToAction("Index");
            }
            return NotFound();
        }



    [HttpGet]
        public IActionResult Edit(int id)
        {

            Anime sh = dbContext.AnimeTable.SingleOrDefault(m => m.Id == id);
            if (sh != null)
                return View(sh);

            return NotFound();
        }

        [HttpPost]
        public IActionResult Edit(int id, Anime changedAnime)
        {


            if (!ModelState.IsValid)//if data is invalid
            {
                return View();
            }



            Anime sh = dbContext.AnimeTable.SingleOrDefault(m => m.Id == id);
            if (sh != null)
            {
                sh.Name = changedAnime.Name;
                sh.ReleaseYear = changedAnime.ReleaseYear;
                sh.EpisodeCount = changedAnime.EpisodeCount;
                sh.Description = changedAnime.Description;
                sh.Reviews = changedAnime.Reviews;
                dbContext.SaveChanges();
                return RedirectToAction("Index");
            }
            return NotFound();
        }
    }
}