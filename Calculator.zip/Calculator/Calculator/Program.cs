﻿using System;

namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            //double a = 42;
            //double b = 119;
            //double c = a + b;
            //Console.WriteLine(c);
            //Console.ReadKey();

            double num1 = 0;
            double num2 = 0;

            Console.WriteLine("THE CALCULATOR\r");
            Console.WriteLine("--------------\n");

            Console.WriteLine("Please enter in a number: ");
            num1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Please enter another number: ");
            num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Choose an operator from the following list: ");
            Console.WriteLine("\ta - Add");
            Console.WriteLine("\ts - Subtract");
            Console.WriteLine("\tm - Multiply");
            Console.WriteLine("\td - Divide");
            Console.Write("Your option?");

            switch (Console.ReadLine())
            {
                case "a":
                    Console.WriteLine($"Your result: {num1} + {num2} = " + (num1 + num2));
                    break;
                case "s":
                    Console.WriteLine($"Your result: {num1} - {num2} = " + (num1 - num2));
                    break;
                case "m":
                    Console.WriteLine($"Your result: {num1} * {num2} = " + (num1 * num2));
                    break;
                case "d":
                    while (num2 == 0)
                    {
                        Console.WriteLine("Enter a non-zero divisor: ");
                        num2 = Convert.ToDouble(Console.ReadLine());
                    }
                    Console.WriteLine($"Your result: {num1} / {num2} = " + (num1 / num2));
                    break;
            }
            Console.WriteLine("Press any key to close the Calculator");
            Console.ReadKey();
        }

    }
}
