﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StoryTime
{
    class MabLib
    {//constructor and encapsulation 
        private string s; 
        public string S 
        {
            get;
            set;
        }
        private enum Mablib //private enum value is access in Fun() to create int value in MabLib
        {
            Num = 13,
        }
         public static void Fun()
        {   //created values and enum reference to gather information from user to create funny story
            Console.Write("Please enter a Adjective: ");
            var value1 = Console.ReadLine();

            Console.Write("Please enter a Plural Noun: ");
            var value2 = Console.ReadLine();

            Console.Write("Please enter a Plural Noun: ");
            var value3 = Console.ReadLine();

            Console.Write("Please enter a Silly Word: ");
            var value4 = Console.ReadLine();

            Console.Write("Please enter a Type of Liquid: ");
            var value5 = Console.ReadLine();

            Console.Write("Please enter a Adjective: ");
            var value6 = Console.ReadLine();

            Console.Write("Please enter a Noun: ");
            var value7 = Console.ReadLine();

            Console.Write("Please enter a Verb: ");
            var value8 = Console.ReadLine();

            Console.Write("Please enter a Plural Noun: ");
            var value9 = Console.ReadLine();

            Console.Write("Please enter a Verb ending in ing: ");
            var value10 = Console.ReadLine();

            var nummethod = Mablib.Num;

            Console.Write("Please enter a action movie: ");
            var value11 = Console.ReadLine();

            Console.Write("Please enter a Plural Noun: ");
            var value12 = Console.ReadLine();

            Console.Write("Please enter a Noun: ");
            var value13 = Console.ReadLine();

            Console.WriteLine();
            Console.WriteLine();
            //Funny MabLib story is created from code
            Console.WriteLine("American children are fascinated by " + value1 + " stuff - Like stories");
            Console.WriteLine("that scare the " + value2 + " off them or make their " + value3);
            Console.WriteLine("stand on end. Scientists say this because being frightened causes the");
            Console.WriteLine(value4 + " gland to function and puts " + value5 + " into");
            Console.WriteLine("their blood, and everyone knows that makes kids feel " + value6 + ".");
            Console.WriteLine("When they are scared by a movie or a " + value7 + ", boys laugh");
            Console.WriteLine("and holler and " + value8 + ". But girls cover their eyes with their");
            Console.WriteLine(value9 + " and keep screaming and " + value10 + ". Most");
            Console.WriteLine("kids get over this by the time they are " + (int)nummethod + " years old. Then");
            Console.WriteLine("they like movies like " + value11 + " or Avengers");
            Console.WriteLine(value12 + ", or, if they are girls, they like movies about a boy meeting");
            Console.WriteLine("a " + value13 + " and falling in love. Of course, that can be scary, too.");
        }
    }
}