﻿using System;

namespace StoryTime
{
    class Program
    {
        public static void Main(string[] args)
        {
            MabLib a = new MabLib();  //foreach loop that print off line by line blastoff
            a.S = ("3 2 1 Blastoff!");

            foreach (var start in a.S)
                Console.WriteLine(start);

            Console.WriteLine();
            MabLib.Fun(); //initiates class fun

        }
    }
}
//dr li input.  use a do while loop. and you can ask user if they want to play again or end the program.